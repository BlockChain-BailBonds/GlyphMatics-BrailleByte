from __future__ import annotations
import argparse, hashlib, json, lzma, os, statistics, tempfile, zlib
from pathlib import Path
from semzip.configs import PRESETS
from semzip.engine import CompressionEngine


def corpus() -> dict[str, bytes]:
    root=Path(__file__).resolve().parent
    items={
        "semzip_engine.py": (root/'semzip/engine.py').read_bytes(),
        "semzip_glyphmatics.py": (root/'semzip/glyphmatics.py').read_bytes(),
        "linux_true_elf": Path('/bin/true').read_bytes(),
        "etc_services": Path('/etc/services').read_bytes(),
    }
    # realistic-ish structured application payload: varied JSON records, not one repeated blob.
    rows=[]
    for i in range(650):
        rows.append(json.dumps({"id":i,"tenant":f"tenant-{i%37}","status":["open","closed","pending"][i%3],"score":(i*7919)%10000,"route":f"/api/v{1+i%3}/objects/{i%211}","flags":[i%2==0,i%5==0,i%11==0]}, separators=(',',':')))
    items['structured_json']='\n'.join(rows).encode()
    # Already compressed and incompressible controls are required for a general claim.
    natural=items['structured_json'] + items['semzip_engine.py']*4
    items['already_compressed']=zlib.compress(natural,9)
    seed=hashlib.sha256(b'SEMZIP-real-world-control').digest()
    buf=bytearray(); counter=0
    while len(buf)<131072:
        buf += hashlib.sha256(seed+counter.to_bytes(8,'little')).digest(); counter+=1
    items['high_entropy_control']=bytes(buf[:131072])
    return items


def gmean(xs):
    import math
    return math.exp(sum(math.log(max(x,1e-300)) for x in xs)/len(xs))


def run():
    data=corpus(); rows=[]
    configs=[]
    for preset in PRESETS:
        configs.append((preset,'lzma'))
    configs.extend([('balanced','zlib'),('microdelta','zlib')])
    for preset,codec in configs:
        ratios=[]; baseline_adv=[]; valid=True
        for name,payload in data.items():
            engine=CompressionEngine(codec=codec,preset=preset)
            packed,stats=engine.compress_bytes(payload,name)
            restored,_=engine.decompress_bytes(packed)
            if restored!=payload: valid=False; break
            raw_lzma=len(lzma.compress(payload,preset=9|lzma.PRESET_EXTREME))
            raw_zlib=len(zlib.compress(payload,9))
            best_raw=min(raw_lzma,raw_zlib)
            ratio=len(payload)/len(packed) if packed else float('inf')
            ratios.append(ratio)
            baseline_adv.append(best_raw/len(packed))
            rows.append({"preset":preset,"codec":codec,"file":name,"original":len(payload),"packed":len(packed),"ratio":ratio,"vs_best_raw":best_raw/len(packed),"ok":True})
        if valid:
            rows.append({"preset":preset,"codec":codec,"file":"__SUMMARY__","original":sum(len(v) for v in data.values()),"packed":None,"ratio":gmean(ratios),"vs_best_raw":gmean(baseline_adv),"ok":True,"min_ratio":min(ratios),"max_ratio":max(ratios)})
    summaries=[r for r in rows if r['file']=='__SUMMARY__']
    summaries.sort(key=lambda r:r['ratio'], reverse=True)
    best=summaries[0]
    out={"claim_target_x":2313.0,"claim_pass":best['ratio']>=2313.0 and best['min_ratio']>=2313.0,"criterion":"A general claim requires every required corpus class and the geometric mean to reach the target.","best":best,"summaries":summaries,"rows":rows}
    Path('benchmark_results.json').write_text(json.dumps(out,indent=2))
    print(json.dumps(out,indent=2))

if __name__=='__main__': run()
