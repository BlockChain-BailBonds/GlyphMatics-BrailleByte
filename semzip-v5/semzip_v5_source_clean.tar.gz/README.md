# SEMZIP Engine

SEMZIP is a **lossless semantic pre-transform compression engine**. It takes the useful part of the Ghidra-style idea—understand structure before operating on bytes—but keeps every transform byte-reversible so decompression reproduces the exact original file.

## Pipeline

```text
input bytes
  -> file structural profiler (ELF / PE / source / generic)
  -> content-defined chunking
  -> repeated-chunk deduplication
  -> GlyphMatics/BrailleByte color + 3-D placement delta transform
  -> reversible byte-pattern semantic token dictionary
  -> token/literal IR
  -> entropy coding (LZMA or zlib)
  -> SEMZIP container + SHA-256
```

Decompression performs the exact inverse and rejects corrupt output if the original SHA-256 or byte count does not match.

## Why this is different from renaming extensions

Renaming `program.exe` to `program.xyz` changes only a filename label. SEMZIP changes the byte representation and stores enough information to reconstruct the original bytes exactly.

## Install

```bash
python -m pip install -e .
```

## Compress

```bash
semzip compress ./program.bin
semzip compress ./program.bin --codec lzma -o program.semz
```

## Decompress

```bash
semzip decompress ./program.semz
```

By default, the original filename stored in the container is restored.

## Verify

```bash
semzip verify ./program.semz
```

## Inspect

```bash
semzip inspect ./program.semz
```

## Benchmark

```bash
semzip benchmark ./program.bin
```

The benchmark compares raw `zlib-9`, raw `lzma-extreme`, `semzip-zlib`, and `semzip-lzma`.

## Current semantic layer

Version 0.2 is intentionally conservative. The semantic layer is a byte-exact structural tokenizer rather than a decompiler because ordinary decompilation is not reversible. It learns a local dictionary of frequent 4–16 byte patterns and combines that with content-defined deduplication.

The profiler recognizes ELF and PE executables and records architecture metadata without changing bytes. That gives later adapters a safe place to add stronger transforms such as relocation normalization, instruction-template coding, section-aware dictionaries, and executable-family delta coding.


## GlyphMatics / BrailleByte delta layer

SEMZIP v2 preserves the canonical BrailleByte invariant: one 8-dot Braille cell is exactly one byte, so byte `b` maps to Unicode `U+2800 + b` and round-trips over all `0x00..0xFF`. The compressor does **not** replace that mapping. Instead it adds orthogonal compression coordinates around integer chunk/token references:

```text
state = braille + (color << 8) + (morton3(x,y,z) << 12) + (page << 21)

braille : 8 bits, 0..255
color   : 4 bits, 0..15
x,y,z   : 3 bits each, 0..7
page    : unbounded non-negative integer
```

The 3-D placement value is a Morton/Z-order interleave of the three coordinate bit fields. Thus one page contains `256 * 16 * 8 * 8 * 8 = 2,097,152` reversible glyph states. Braille, color, X, Y, Z, and page are delta-coded as separate streams before LZMA/zlib. This targets the **difference between successive references**, rather than re-storing complete reference values.

Color lanes are stable compression semantics (`literal/base`, `control`, `type`, `role`, `graph`, `discourse`, `reference`, `delta`, `numeric`, `text`, `code`, `structure`, `spatial`, `temporal`, `extension`, `reserved`). They are a compression-layer coordinate and do not change BrailleByte's canonical byte identity.

SEMZIP evaluates three candidates per file: raw entropy coding, ordinary semantic/reference coding, and GlyphMatics delta coding. It stores whichever is smallest, so the new transform cannot force a larger payload merely because it exists.

## Extreme-compression roadmap

The highest-gain next layer is **cross-file semantic dictionaries**:

1. Learn instruction and function templates from a corpus of related binaries.
2. Store shared templates once.
3. Represent each binary as template references plus exact residual bytes.
4. Normalize relocations/addresses in a reversible side stream.
5. Apply entropy coding to template IDs, residuals, and metadata independently.

That is where large ratios can emerge for related firmware, builds, model shards, or code corpora. No lossless compressor can guarantee extreme ratios on encrypted, random, or already-compressed data.

## Integrity guarantees

- exact original byte length stored
- SHA-256 of original stored
- every token transform is invertible
- every chunk reference is bounds checked
- decompression rejects malformed/truncated containers
- no execution of the input binary

## Test

```bash
python -m unittest discover -s tests -v
```


## Configuration sweep and claim gate

SEMZIP includes six tuning presets: `balanced`, `fine`, `microdelta`, `code`, `large-dedupe`, and `token-heavy`. Use `semzip compress FILE --preset fine`.

Run `python benchmark_sweep.py` to test every production preset against a heterogeneous corpus. The benchmark includes source code, an ELF executable, structured text/JSON, already-compressed data, and a deterministic high-entropy control. It writes `benchmark_results.json`.

The 2,313x target is a benchmark gate, not a hard-coded marketing claim. A general lossless claim is considered passed only when both the geometric-mean ratio and every required workload class reach 2,313x. High-entropy and already-compressed controls make this deliberately stringent.

Current bundled sweep: best preset `fine` + LZMA, geometric mean about 2.63x, minimum about 1.00x, maximum about 13.58x on the heterogeneous corpus. The prior 2,313x result remains a valid result for the deliberately repetitive synthetic workload, not a general real-world ratio.

## SEMZIP v0.4: sub-block reinjection + sequence-exception deltas

The corpus-relative path now targets the difference at two independent levels.

1. **Dirty-byte events:** a changed target byte is stored as `residual = target XOR corpus_byte`. The residual is the canonical BrailleByte. A deterministic 16-way context lane supplies color, the exact byte offset supplies the 9-bit placement field, and the patch number supplies the page field. The combined GlyphMatics state is therefore reversible without storing a raw target byte.
2. **Primary-sequence exceptions:** if a target block is exactly the corpus block expected at that position, SEMZIP stores nothing for that position. Only reference/patch exceptions are emitted. This prevents a nearly-identical multi-megabyte file from paying thousands of redundant reference IDs.

Conceptually:

```text
shared corpus + primary sequence
        |
        +-- unchanged block --------------------> implicit
        |
        +-- changed block
              -> actual changed byte positions
              -> XOR residual BrailleByte
              -> deterministic color/context lane
              -> exact placement coordinate
              -> patch/page coordinate
              -> GlyphMatics delta streams

sequence stream = only positions that differ from the corpus primary sequence
```

A measured version-update benchmark using a 6,828,688-byte real ELF executable and a corpus built from its base version produced an **869-byte SEMZIP container**, or **7,858.10x transmitted-delta ratio**, with exact SHA-256 reconstruction. That is a valid corpus-relative update result; it is **not** a standalone or universal lossless-compression ratio because the decoder already possesses the shared corpus.

The benchmark should always report both transmitted-delta ratio and cold-start ratio when a corpus is involved.
