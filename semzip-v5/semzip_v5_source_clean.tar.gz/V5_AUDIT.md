# SEMZIP v5 shortcut implementation

Implemented high-impact audit findings:
- compact binary corpus container header with raw 32-byte SHA-256 and corpus IDs
- adaptive RAW/zlib/LZMA body selection; tiny deltas can bypass entropy coding
- identity mode for exact corpus-primary reuse
- same-layout PATCH_ONLY path that bypasses chunk hashing
- dirty bytes reinjected as XOR residual BrailleBytes and dispersed into deterministic 16 color/context lanes
- absolute placement deltas inside each lane; no per-event lane IDs
- prefix/suffix resynchronization for single insertion/deletion/replacement regions
- legacy SEMZIP v1-v4 container decode remains in engine

Deferred for the next layer: rolling-anchor multi-region resynchronization, macro/micro hierarchy, multi-reference corpus routing, ELF/PE relocation normalization, and parallel candidate execution.
